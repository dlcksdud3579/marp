package com.himes.food.view;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ViewScoped;
import javax.inject.Named;

import org.springframework.beans.factory.annotation.Autowired;

import com.himes.food.Service.ItemService;
import com.himes.food.model.Item;

@Named
@ViewScoped
public class ItemView implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Autowired
	private ItemService itemService;
	private List<Item> itemList;


	@PostConstruct
	public void init() {
		try {
			Item item = new Item();
			item.setCompSeq(1);

			itemList = itemService.select(item);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public List<Item> getItemList() {
		return itemList;
	}
}

package com.himes.food.view;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ViewScoped;
import javax.inject.Named;

import org.springframework.beans.factory.annotation.Autowired;

import com.himes.food.Service.CarService;
import com.himes.food.model.Car;


@Named
@ViewScoped
public class CarsView implements Serializable {

  private static final long serialVersionUID = 1L;

  @Autowired
  private CarService car_Service;

  private List<Car> carList;

  @PostConstruct
  public void init() {
    try {
    	Car car = new Car();
    	carList = car_Service.select(car);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  }

  public List<Car> getCarList() {
    return carList;
  }
}

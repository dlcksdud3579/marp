package com.himes.food.view;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ViewScoped;
import javax.inject.Named;

import org.springframework.beans.factory.annotation.Autowired;

import com.himes.food.model.Car;
import com.himes.food.model.Item;


@Named
@ViewScoped
public class ItemsView implements Serializable {

  private static final long serialVersionUID = 1L;

  private List<Item> items;

  @PostConstruct
  public void init() {

  }

  public List<Item> getItems() {
    return items;
  }
}

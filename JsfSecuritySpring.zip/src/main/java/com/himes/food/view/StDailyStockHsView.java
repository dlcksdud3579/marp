package com.himes.food.view;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;


import javax.annotation.PostConstruct;
import javax.faces.annotation.RequestParameterValuesMap;
import javax.faces.view.ViewScoped;
import javax.inject.Named;

import org.primefaces.event.SelectEvent;
import org.primefaces.model.chart.Axis;
import org.primefaces.model.chart.AxisType;
import org.primefaces.model.chart.CategoryAxis;
import org.primefaces.model.chart.LineChartModel;
import org.primefaces.model.chart.LineChartSeries;
import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.databind.util.StdDateFormat;
import com.himes.food.Service.StDailyStockHsService;
import com.himes.food.model.StDailyStockHs;

import lombok.Getter;
import lombok.Setter;


@Named
@ViewScoped
@Getter
@Setter
public class StDailyStockHsView implements Serializable {

	private static final long serialVersionUID = 7418716340603606146L;

	@Autowired
	private StDailyStockHsService sdsh_Service;

	private List<StDailyStockHs> sdshList ;
	
	

	private  Date endMaxDate;
	private  Date startMaxDate ;
	private List<StDailyStockHs> selectedSdsh = new ArrayList<>();
	
	
	StDailyStockHs sdsh = new StDailyStockHs();

	private LineChartModel lineModel;

	@PostConstruct
	public void init() {
		try {
			sdsh.setEndDate(new Date());
			endMaxDate = new Date();
			sdsh.setStartDate(new Date(sdsh.getEndDate().getTime() -(1000 * 60 * 60 * 24)*14));
			startMaxDate = new Date(endMaxDate.getTime() -(1000 * 60 * 60 * 24)*14);
			selectionSdshList();
			
			// 미리 Y인 사항을 선택해서 보여준다   
			for (StDailyStockHs stDailyStockHs : sdshList) {
				if(stDailyStockHs.StockYn.compareTo("Y") ==0)
					selectedSdsh.add(stDailyStockHs);
			}
			createLineModels();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void selectionSdshList() {
		try {
			
			sdsh.setCompSeq(1);
			sdsh.setStartDate(sdsh.getStartDate());
			sdshList = sdsh_Service.select(sdsh);
			selectedSdsh.clear();


		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private LineChartModel initLinearModel() {
		LineChartModel model = new LineChartModel();
        
        for (StDailyStockHs stDailyStockHs : selectedSdsh) {
        	LineChartSeries series = new LineChartSeries();
        	series.setLabel(stDailyStockHs.ItemNm);
        	series.set(getDay(0),stDailyStockHs.day_1);
        	series.set(getDay(1),stDailyStockHs.day_2);
        	series.set(getDay(2),stDailyStockHs.day_3);
        	series.set(getDay(3),stDailyStockHs.day_4);
        	series.set(getDay(4),stDailyStockHs.day_5);
        	series.set(getDay(5),stDailyStockHs.day_6);
        	series.set(getDay(6),stDailyStockHs.day_7);
        	series.set(getDay(7),stDailyStockHs.day_8);
        	series.set(getDay(8),stDailyStockHs.day_9);
        	series.set(getDay(9),stDailyStockHs.day_10);
        	series.set(getDay(10),stDailyStockHs.day_11);
        	series.set(getDay(11),stDailyStockHs.day_12);
        	series.set(getDay(12),stDailyStockHs.day_13);
        	series.set(getDay(13),stDailyStockHs.day_14);
        	series.set(getDay(14),stDailyStockHs.day_15);
        	model.addSeries(series);
		}
        
        
		return model;
	}

	public void createLineModels() {
		lineModel = initLinearModel();
		lineModel.setTitle("일일 재고현황 차트");
		lineModel.setLegendPosition("e");
		lineModel.setShowPointLabels(true);
		lineModel.getAxes().put(AxisType.X, new CategoryAxis("Dates"));
		Axis yAxis = lineModel.getAxis(AxisType.Y);
		yAxis.setLabel("재고");
		yAxis.setMin(0);
		yAxis.setMax(300);
	}

	public String getDay(int index) {
		
		Calendar c = Calendar.getInstance();
		c.setTime(sdsh.getStartDate());
		c.add(Calendar.DAY_OF_MONTH, index);
		return (c.get(Calendar.MONTH)+1) + "/" + (c.get(Calendar.DAY_OF_MONTH));
	}
	
	
	public void handleStartDateSelect(SelectEvent event) {
	   
		sdsh.setEndDate(new Date(sdsh.getStartDate().getTime() +(1000 * 60 * 60 * 24)*14));

	}
	public void handleEndDateSelect(SelectEvent event) {
		sdsh.setStartDate(new Date(sdsh.getEndDate().getTime() -(1000 * 60 * 60 * 24)*14));
	}
	
	public void searchBtnAction()
	{
		
		selectionSdshList();
		
		System.out.println("\n-----------------------------------------------------");
		System.out.println(sdsh.toString());
		System.out.println("\n------------------------------------------------------");
	}
	
}

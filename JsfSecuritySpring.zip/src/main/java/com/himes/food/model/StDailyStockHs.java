package com.himes.food.model;


import java.util.Date;

import lombok.*;

@Data
@NoArgsConstructor
public class StDailyStockHs {

	/// 법인일렬번호
	public int CompSeq;
	
	/// 일자
	public Date Date;

	/// 품목일렬번호
	public int ItemSeq;
	
	/// 재고수량
	public int StockQty;
	
	/// 가용재고수량	
	public int AvailableQty;

	/// 대분류명
	public String ItemCls1Nm;

	/// 중분류명
	public String ItemCls2Nm;

	/// 단위명
	public String UnitNm;


	/// 대분류
	public String ItemCls1;

	/// 품명
	public String ItemNm;

	/// 품번
	public String ItemNo;

	/// 재고관리표시
	public String StockYn;


	/// 시작날짜
	public Date StartDate;


	/// 종료날짜
	public Date EndDate;

	// 그리드뷰 날짜
	/// 날짜
	public int day_1;

	/// 날짜
	public int day_2;

	/// 날짜
	public int day_3;

	/// 날짜
	public int day_4;

	/// 날짜
	public int day_5;

	/// 날짜
	public int day_6;

	/// 날짜
	public int day_7;

	/// 날짜
	public int day_8;

	/// 날짜
	public int day_9;

	/// 날짜
	public int day_10;

	/// 날짜
	public int day_11;

	/// 날짜
	public int day_12;

	/// 날짜
	public int day_13;

	/// 날짜
	public int day_14;

	/// 날짜
	public int day_15;

}

package com.himes.food.model;
import lombok.*;

@Data
@NoArgsConstructor
public class Car {
	

  private long id;
  private String brand;
  private int year;
  private String color;
}

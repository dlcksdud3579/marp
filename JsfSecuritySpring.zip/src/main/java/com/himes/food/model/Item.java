package com.himes.food.model;

import java.sql.Date;

import lombok.*;

@Data
@NoArgsConstructor
public class Item {
	
	private int CompSeq;
	private int ItemSeq;
	private String ItemNo;
	private String ItemNm;
	private String ItemNmEng;
	private String ItemCls1;
	private String ItemCls2;
	private String ItemCls3;
	private String Spec;
	private String MaterialCd;
	private String UnitCd;
	private float Weight;
	private int CustSeq;
	private int ProdLotUnitQty;
	private int SafeStkQty;
	private int LeadTime;
	private char InspYn;
	private char ProcYn;
	private char LotYn;
	private char StockYn;
	private char UseYn;
	private byte[] Image;
	private String ItemReportNo;
	private String Remark;
	private String RegUserId;
	@NonNull
	private Date RegDt;
	@NonNull
	private String ModUserId;
	private Date ModDt;

}

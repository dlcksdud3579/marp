package com.himes.food.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.himes.food.dao.ItemDAO;
import com.himes.food.model.Item;

@Service
public class ItemService {
	
	@Autowired
	private ItemDAO itemDao;
	  
	public List<Item> select(Item item) throws Exception
	{
		return itemDao.selectList(item);
	}
	  
	 
}

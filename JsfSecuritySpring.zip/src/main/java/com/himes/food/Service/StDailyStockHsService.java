package com.himes.food.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.himes.food.dao.StDailyStockHsDAO;
import com.himes.food.model.StDailyStockHs;


@Service
public class StDailyStockHsService {
	
	@Autowired
	private StDailyStockHsDAO sdshDao;
	  
	public List<StDailyStockHs> select(StDailyStockHs sdsh) throws Exception
	{
		return sdshDao.selectList(sdsh);
	}
	  
	  
	  
}

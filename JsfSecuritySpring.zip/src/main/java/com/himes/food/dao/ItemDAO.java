package com.himes.food.dao;
import org.apache.ibatis.annotations.Mapper;

import org.springframework.stereotype.Repository;

import com.himes.food.model.Item;

@Repository
@Mapper
public interface ItemDAO extends DAO<Item>{

}

package com.himes.food.dao;
import org.apache.ibatis.annotations.Mapper;

import org.springframework.stereotype.Repository;

import com.himes.food.model.Car;

@Repository
@Mapper
public interface CarDAO extends DAO<Car>{

}

package com.himes.food.dao;
import java.util.List;
public interface DAO<T>{
	List<T> selectList(T t) throws Exception;
}
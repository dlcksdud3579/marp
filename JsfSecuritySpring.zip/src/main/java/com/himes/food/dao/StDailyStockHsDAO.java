package com.himes.food.dao;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.himes.food.model.StDailyStockHs;

@Repository
@Mapper
public interface StDailyStockHsDAO extends DAO<StDailyStockHs>{
}
